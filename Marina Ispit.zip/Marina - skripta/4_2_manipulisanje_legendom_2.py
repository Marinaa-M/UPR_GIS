root = QgsProject.instance().layerTreeRoot()

zpd = QgsProject.instance().mapLayersByName('ZPD_VA')[0]

# kreira "privremeni" lejer
layer1 = QgsVectorLayer('D:/Diplomski_rad/priv_lejer', 'privremeni', 'memory')
# dodaje lejer na poslednju poziciju u legendi
root.addLayer(layer1)
# dodaje lejer na specificno navedenu poziciju
#root.insertLayer(3, layer1)

# moguce je takodje dodati lejer u registar lejera mape, kao sto je radjeno u prethodnim skriptama
# QgsProject.instance()addMapLayer(layer1)

node_layer = root.findLayer(zpd.id())
print('Cvor lejera: ', node_layer)
print('Lejer na mapi: ', node_layer.layer())

# dodavanje grupa
node_group1 = root.addGroup('Grupa')
# dodaje podgrupu prethodno kreiranoj grupi
node_subgroup1 = node_group1.addGroup('Podgrupa')

# Prebacivanje cvorova i grupa
# prvo se klonira postojeci cvor
cloned_group1 = node_group1.clone()
# zatim se pomera cvor (ujedno se pomeraju i lejeri i podgrupe)na vrh
root.insertChildNode(0, cloned_group1)
# uklanjanje originalnog cvora
root.removeChildNode(node_group1)
