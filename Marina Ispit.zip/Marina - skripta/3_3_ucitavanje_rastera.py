import os

# Ucitava raster u projekat


#putanja do rastera (TIF)
put_do_dema = 'D:/Diplomski_rad/DEM_Granica_opstine.tif'

rlayer = QgsRasterLayer(put_do_dema, 'DEM')

if not rlayer.isValid():
    print('Lejer nije uspesno ucitan.')
else:
    QgsProject.instance().addMapLayer(rlayer)

# Drugi nacin
# iface.addRasterLayer(put_do_dema, 'DEM')
