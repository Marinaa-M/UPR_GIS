# kreiranje vektora pomocu QgsVectorFileWriter klase

#SaveVectorOptions sadrzi brojne funkcionalnosti za dati proces
lejer = QgsVectorLayer("point?crs=epsg:6316&field=id:integer", "point", "memory")
save_options = QgsVectorFileWriter.SaveVectorOptions()
transform_context = QgsProject.instance().transformContext()

#Piše u GeoPackage format (default)
error = QgsVectorFileWriter.writeAsVectorFormatV2(lejer, "D:/Diplomski_rad/Opstina_Valjevo.gpkg", transform_context, save_options)

if error[0] == QgsVectorFileWriter.NoError:
    print("Uspesno kreiranje lejera.")
else:
    print("Error.")
    
#Piše u shapefile formatu (UTF-8 encoding)
lejer_shp = QgsVectorLayer("polygon?crs=epsg:6316&field=id:integer","polygon", "memory")
save_options.driverName = "ESRI Shapefile"
save_options.fileEncoding = "UTF-8"
error = QgsVectorFileWriter.writeAsVectorFormatV2(lejer_shp, "D:/Diplomski_rad/Katastarske_opstine_Valjevo.shp", transform_context,save_options)

if error[0] == QgsVectorFileWriter.NoError:
    print("Uspesno kreiranje lejera.")
else:
    print("Error.")
