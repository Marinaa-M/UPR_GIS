#Korišćeni lejer: Naselja Valjevo
lejer = iface.activeLayer()

renderer = lejer.renderer()

print("TipNaselja", renderer.type())
print(renderer.dump())

#Menja simbol lejera
simbol = QgsMarkerSymbol.createSimple({"name": "circle", "color": "blue"})
renderer.setSymbol(simbol)
lejer.triggerRepaint()

#Ukoliko želimo da vidimo sve osobenosti prvog simbol lejera koji smo kreirali 
print(renderer.symbol().symbolLayers()[0].properties())

#Menja veličinu simbola
renderer.symbol().symbolLayer(0).setSize(8)

#Nekim osobenostima nije moguće pristupiti pomoću metoda,
#već se može zameniti simbol u potpunosti
props = lejer.renderer().symbol().symbolLayer(0).properties()
props["name"] = "triangle"
props['color'] = "yellow"
renderer.setSymbol(QgsMarkerSymbol.createSimple(props))

#Prikazuje promene
lejer.triggerRepaint()
