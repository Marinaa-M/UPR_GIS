# Ukoliko se skripta pokrece izvan QGIS-a, potrebno je importovati
# qgis i PyQT klase koje ce se koristiti
# from qgis.core import QgsProject

# Instanciranje projekta
project = QgisProject.instance()

# Ucitavanje projekta
project.read('D:/Diplomski_rad/Valjevo_projekat.qqz')

# Ukoliko menjamo nesto u projektu, uvek mozemo da to da sacuvamo pod istim imenom
project.write()
# Ili pod razlicitim
project.write('D:/Diplomski_rad/Valjevo_drugi_naziv.qqz')

# Menja lose "putanje", u slucaju da doslo do promene lokacije lejera, promene adrese od hosta baze podataka...
def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)'''
