raster = QgsProject.instance().mapLayersByName('DEM_Granica_opstine')[0]

# postavljanje upita za trenutni renderer
print(raster.renderer())
# vraca tip rastera
print(raster.renderer().type())

# menjanje boje (rendera) za rastere sa jednim kanalom
# kreiranje skale (objekat QgsColorRampShader)
skala = QgsColorRampShader()
# biranje tipa skale
skala.setColorRampType(QgsColorRampShader.Interpolated)
# kreiranje boja koje ce se koristiti (zuta i zelena)
lista = [QgsColorRampShader.ColorRampItem(0, QColor(0,255,0)),
QgsColorRampShader.ColorRampItem(255, QColor(255,255,0))]
# dodavanje boja skali
skala.setColorRampItemList(lista)
shader = QgsRasterShader()
shader.setRasterShaderFunction(skala)

# povezivanje shader-a sa rasterom
# broj 1 ukazuje broj kanala
renderer = QgsSingleBandPseudoColorRenderer(raster.dataProvider(), 1, shader)
raster.setRenderer(renderer)
raster.triggerRepaint()

# za multispektralni (satelitski snimci npr.)
# moze koristiti za kreiranje laznog i pravog kolor kompozita
# primer ispod je za pravi kolor kompozit
raster_multi = QgsProject.instance().mapLayersByName('DEM_Granica_opstine')[0]
raster_multi.renderer().setBlueBand(1)
raster_multi.renderer().setGreenBand(2)
raster_multi.renderer().setRedBand(3)
raster_multi.triggerRepaint()

# upit za dobijanje vrednosti celije rastera, na osnovu koordinata
# vraca tuple sa bool-eanskim vrednostima
val, res = raster_multi.dataProvider().sample(QgsPointXY(7362930.7, 4937564.1), 1)

print(val, res)
# drugi nacin, koriscenjem identify metoda (vraca QgsRasterIdentifyResult objekat
# vraca recnik, sa kanalima kao kljucevima i vrednostima kanala kao vrednostima
ident = raster_multi.dataProvider().identify(QgsPointXY(7362930.7, 4937564.1), QgsRaster.IdentifyFormatValue)
if ident.isValid():
    print(ident.results())

