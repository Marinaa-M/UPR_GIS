root = QgsProject.instance().layerTreeRoot()
zpd = QgsProject.instance().mapLayersByName('ZPD_VA')[0]


# pomeranje lejera u legendi
# kreiranje objekta QgsLayerTreeLayer iz zpd po njegovom ID-u
zpdvektor = root.findLayer(zpd.id())
# klonira se prethodno kreirani objekat
zpdvektorklon = zpdvektor.clone()
# uzima "roditelja". Ukoliko je rezultat None,
# znaci da lejer nije ni u jednog grupi i vratice ''
roditelj = zpdvektor.parent()
# pomera se klonirani lejer na vrh
roditelj.insertChildNode(0, zpdvektorklon)
# uklanja se originalni lejer (zpdvektor)
root.removeChildNode(zpdvektor)

# prebacivanje lejera u odredjenu grupu (slican postupak kao kod pomeranja)
zpdvektor = root.findLayer(zpd.id())
zpdvektorklon = zpdvektor.clone()
# kreiranje nove grupe
grupa1 = root.addGroup('Grupa')
roditelj = zpdvektor.parent()
grupa1.insertChildNode(0, zpdvektorklon)
roditelj.removeChildNode(zpdvektor)

# jos neke metode, koje mogu da se koriste za menjanje
# grupa i lejera

# menjanje imena grupe
# node_group1.setName('Slarni_paneli_kriterijumi')
