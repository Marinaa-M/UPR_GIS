# korisceni lejer = Korina Valjevo
lejer = iface.activeLayer()
print(lejer.isEditable())

#Skuplja FID-ove u listu
fidd = []
for feature in lejer.getFeatures():
    fidd.append(feature.id())
print(fidd)

feat1 = feat2 = QgsFeature(lejer.fields())
fid = -2 # 
feat1.setId(fid)

#Dodaje dva featurea (instance QgsFeature)
# lejer.addFeatures([feat1,feat2])

#Briše feature sa prethodno definisanim FID-om
# lejer.deleteFeature(fid)

#Ažurira atribut preko indeksa tog atributa za odredjenu vrednost
indeksAtributa = 2
vrednost = "Sport i rekreacija"
lejer.changeAttributeValue(fid, indeksAtributa, vrednost)

#Ukoliko želimo da dodamo atribut
lejer.addAttribute(QgsField("Klasa", QVariant.Int))

#Ukoliko želimo da obrišemo atribut
# lejer.deleteAttribute(indeksAtributa)
