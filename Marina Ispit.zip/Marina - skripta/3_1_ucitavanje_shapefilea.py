import os #potrebno i u QGIS-u
# from qgis.core import (QgsVectorLayer) - potrebno u standalone

# Uzima lejer na toj lokaciji
putanja_do_katastarskih_opstina = 'D:/Diplomski_rad/Katastarske_opstine_Valjevo.shp'

# Format je:
# vlayer = QgsVectorLayer(data_source, layer_name, provider_name)
vlayer = QgsVectorLayer(putanja_do_katastarskih_opstina, 'Katastarske_opstine_Valjevo', 'ogr')

# Proverava da li je lejer uspesno ucitan
if not vlayer.isValid():
    print('Lejer nije uspesno ucitan')
else:
    QgsProject.instance().addMapLayer(vlayer)
