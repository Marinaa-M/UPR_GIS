'''from qgis.core import (
    QgsMessageLog,
    QgsGeometry,
)

from qgis.gui import (
    QgsMessageBar,
)

from qgis.PyQt.QtWidgets import (
    QSizePolicy,
    QPushButton,
    QDialog,
    QGridLayout,
    QDialogButtonBox,
)'''  #Ukoliko je standalone

def pokaziGresku():
    pass

widget = iface.messageBar().createMessage('Lejeri koji nedostaju', 'Prikazi')
dugme = QPushButton(widget)
dugme.setText('Prikazi')
dugme.pressed.connect(pokaziGresku)
widget.layout().addWidget(dugme)
iface.messageBar().pushWidget(widget, Qgis.Warning)

class Dijalog(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.setLayout(QGridLayout())
        self.layout().setContentsMargins(50,50,50,50)
        self.buttonbox = QDialogButtonBox(QDialogButtonBox.Open)
        self.buttonbox.accepted.connect(self.run)
        self.layout().addWidget(self.buttonbox,0,0,2,1)
        self.layout().addWidget(self.bar,0,0,1,1)
    def run(self):
        self.bar.pushMessage('Projekat', 'Programiranje', level=Qgis.Info)

dijalog = Dijalog()
dijalog.show()