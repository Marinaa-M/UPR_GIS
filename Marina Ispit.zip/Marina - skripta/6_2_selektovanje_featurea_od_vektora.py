# Selektuje feature-e na osnovu odredjenog izraza
# Razlikuje se od lejera na kom se koristi (u ovom slucaju Katastarske opstine)
# prvi argument predstavlja izraz, na osnovu kog se vrsi upit
lejer.selectByExpression('"nagib" > 0.5 and "povrsina" > 20', QgsVectorLayer.SetSelection)

# menja boju selekcije (default je zuta)
iface.mapCanvas().setSelectionColor(QColor('blue'))

# brise selektovane feature
# lejer.removeSelection()

#selected_fid = []

# uzima prvi feature id iz lejera
'''for feature in lejer.getFeatures():
    selected_fid.append(feature.id())
    break'''

# dodaje ove feature selektovanoj listi
# lejer.select(selected_fid)

# lejer.removeSelection()

# atributima se moze pristupiti na osnovu imena ili indeksa
print(feature['povrsina'])
print(feature[1])

# ukoliko su nam potrebni samo selektovani feature-i
selekcija = lejer.selectedFeatures()
for feature in selekcija:
    if feature['povrsina'] < 20:
        print('Povrsina je manja od 20km kvadratnih')
    else:
        print('Povrsina je veca od 20km kvadratnih')
