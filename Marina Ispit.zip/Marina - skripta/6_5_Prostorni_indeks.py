#Korišćenje prostornih indeksa

#Korišćeni lejer = Putevi Valjevo
lejer = iface.activeLayer()
feat = QgsFeature(lejer.fields())

#Instanciranje objekta QgsSpatialIndex
indeks = QgsSpatialIndex(lejer.getFeatures())

#Drugi način
# index = QgsSpatialIndex()
# index.addFeature(feat)
