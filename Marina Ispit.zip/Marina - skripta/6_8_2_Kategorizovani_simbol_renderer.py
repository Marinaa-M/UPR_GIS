#Korišćeni lejer Naselja Valjevo
lejer = iface.activeLayer()

kategorizovani_renderer = QgsCategorizedSymbolRenderer()
#Dodaje par kategorija
kat1 = QgsRendererCategory("1", QgsMarkerSymbol(), "Naz_lejera")
kat2 = QgsRendererCategory("2", QgsMarkerSymbol(), "br_st")
kat3 = QgsRendererCategory("3", QgsMarkerSymbol(), "NazNaselja")

#Kreiranje simbola za svaku kategoriju
simbol_1 = QgsMarkerSymbol.createSimple({"name": "circle", "color": "red"})
kat1.setSymbol(simbol_1)

simbol_2 = QgsMarkerSymbol.createSimple({"name": "rectangle", "color": "green"})
kat2.setSymbol(simbol_2)

simbol_3 = QgsMarkerSymbol.createSimple({"name": "hexagon", "color": "purple"})
kat3.setSymbol(simbol_3)

#Dodavanje kategorija rendereru
kategorizovani_renderer.addCategory(kat1)
kategorizovani_renderer.addCategory(kat2)
kategorizovani_renderer.addCategory(kat3)

for kat in kategorizovani_renderer.categories():
    print("{}: {} :: {}".format(kat.value(), kat.label(), kat.symbol()))

kategorizovani_renderer.setClassAttribute("Atributi")
lejer.setRenderer(kategorizovani_renderer)
lejer.triggerRepaint()
