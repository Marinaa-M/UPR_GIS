'''from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsPointXY,
)''' #Ukoliko je standalone skripta


crs = QgsCoordinateReferenceSystem('EPSG:6316')
#Štampa 
print(crs.isValid())

wkt = 'GEOGCS["WGS84", DATUM["WGS84", SPHEROID["WGS84", 6378137.0, 298.257223563]],' \
      'PRIMEM["Greenwich", 0.0], UNIT["degree",0.017453292519943295],' \
      'AXIS["Longitude",EAST], AXIS["Latitude",NORTH]]'
proj = '+proj=tmerc +lat_0=0 +lon_0=21 +k=0.9999 +x_0=7500000 +y_0=0 +ellps=bessel +towgs84=682,-203,480,0,0,0,0 +units=m +no_defs'

crs2 = QgsCoordinateReferenceSystem(proj)
print(crs2.isValid())

#Štampa false, i ako je prepisano iz programa

#Komande za pristup informacijama o koordinatnom sistemu

print('QGIS CRS ID: ', crs.srsid())
print('PostGIS SRID: ', crs.postgisSrid())
print('Opis: ', crs.description())
print('Akronim projekcije: ', crs.projectionAcronym())
print('Akronim elipsoida: ', crs.ellipsoidAcronym())
print('Proj String: ', crs.toProj4())

#Proverava da li je geografski ili projektovani koordinatni sistemi
print('Da li je geografski: ', crs.isGeographic())

#Proverava mernu jedinicu za korišćeni koordinatni sistem
print('Merna jedinica mape: ', crs.mapUnits())
