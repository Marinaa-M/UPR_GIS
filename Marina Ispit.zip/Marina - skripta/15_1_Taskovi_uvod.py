'''from qgis.core import (
  QgsProcessingContext,
  QgsTaskManager,
  QgsTask,
  QgsProcessingAlgRunnerTask,
  Qgis,
  QgsProcessingFeedback,
  QgsApplication,
  QgsMessageLog,
)'''  #Ukoliko je standalone

#Načini na koje se sve može kreirati task

#Pomoću klase QgsTask
class PosebanTask(QgsTask):
    pass

#Kreiranje taska iz funkcije
def intenzivnaFunkcija():
    #Odredjeno izvršavanje naredbi koje opterecuje procesor
    pass
    
def posao_obavljen():
    # ...korišćenje dobijenih rezultata iz prethodne funkcije
    pass
    
task = QgsTask.fromFunction('intenzivna funkcija', intenzivnaFunkcija, onfinished=posao_obavljen)


#Kreiranje taska iz algoritama za obradu (procesiranje)
parametri = dict()
kontekst = QgsProcessingContext()
povratna_informacija = QgsProcessingFeedback()

bafer = QgsApplication.instance().processingRegistry().algorithmById('native:buffer')
task = QgsProcessingAlgRunnerTask(bafer, parametri, kontekst, povratna_informacija)