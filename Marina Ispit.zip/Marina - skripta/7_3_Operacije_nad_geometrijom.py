#Korišćeni lejer = Korina Valjevo

lejer = QgsProject.instance().mapLayersByName("KorinaValjevo")[0]
#Može i preko iface.activeLayer()
#Filtrira nazvi klase kojima naziv pocinje sa "P", zatim izvlači njihove feature-e
upit = '"Naz_klase" LIKE \'P%\''
features = lejer.getFeatures(QgsFeatureRequest().setFilterExpression(upit))

#Vrši iteraciju nad feature-ima, i izvršava geometrijsku komputaciju i štampa rezultate
for f in features:
    geom = f.geometry()
    naziv = f.attribute("Povrsina")
    print(naziv)
    print("Povrsina (hektari): ", geom.area()/1000)
    print("Duz_km (km): ", geom.length()/1000)
    
print('-----------------------------------------')

#Alternativni način štampa kod od elipsoida koji se koristi
# print(QgsProject.instance().ellipsoid())

#Štampa sve elipsoide po njihovom kodu
# print(QgsEllipsoidUtils.acronyms())

"""
d = QgsDistanceArea()
d.setEllipsoid('EPSG:6316')

for f in features:
    geom = f.geometry()
    naziv = f.attribute("Povrs_ha")
    print(naziv)
    print("Duz_km (km): ", d.measurePerimeter(geom)/1000)
    print("Povrs_ha (hektari): ", d.measureArea(geom)/1000)
"""
